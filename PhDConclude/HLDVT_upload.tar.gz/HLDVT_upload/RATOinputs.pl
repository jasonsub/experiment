#!/usr/bin/perl -w

# Created by Xiaojun Sun @Jul 1, 2016
# First line is inputs list with separator spaces " ", second line is shuffled vars list with separator comma ","
# extract all inputs from shuffled list, put a "T" at the end as divider then attach inputs

use 5.014;
use strict;
use warnings;

my $cnt = 0;

my $i;

my @inputs;
my @newlist;
my @vars;

while(<>)
{
	chomp;
	my $read_in = $_;
	my @items = split /\s+/;
	if(!defined($items[0])) {next;}  # skip empty lines
	if($items[0] =~ /#/) {next;}  # skip comments
	$cnt++;
	if($cnt == 1)
	{
		@inputs = @items;
	}
	if($cnt == 2)
	{
		@vars = split /,/,$items[0];
		for($i = $#vars; $i >=0; $i--)
		{
			if($vars[$i] ~~ @inputs) {next;}
			if($vars[$i] ~~ @newlist) {next;} # loop in circuit may cause repeating vars..simply ignore them here
			unshift @newlist,$vars[$i];
		}
		push @newlist, "T";
		push @newlist, @inputs;
		local $, = ',';
		print @newlist; print "\n";
	}
}
