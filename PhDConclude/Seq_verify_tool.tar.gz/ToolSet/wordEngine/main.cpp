#include "alphaPoly.h"
#include<vector>
#include<list>
#include<string>
#include<sstream>
#include<map>
#include<set>
#include<fstream>
#include<algorithm>
#include<iostream>
using namespace std;

extern int cavmain(char *filename,char *polyfilename);
extern double diffms;
int main (int argc, char* argv[]) 
{
	if(argc!=3)
	{
		cout<<"Usage: "<<argv[0]<<" inputfile.alg polyFile.poly"<<endl;
		return 1;
	}

	clock_t t;
	t= clock();

	int timesSlept = cavmain(argv[1],argv[2]);

	t = clock() - t;
	
	/*AlphaPoly::setMinpoly("X^8+X^4+X^3+X+1");
	AlphaPoly one = AlphaPoly("X^6+X^4+X+1");

	one.getInverse();*/
	
	cout<<"Total abstraction time is: "<<((t*1000)/CLOCKS_PER_SEC)+(timesSlept*1000)<<" ms."<<endl;

	return 0;
}

