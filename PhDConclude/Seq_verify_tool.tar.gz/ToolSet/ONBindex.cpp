#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cmath>
using namespace std;

bool onb_I(double a, double b, int M)
{
	long sum;
	long power_a = 1;
	long power_b = 1;
	
	while (a>16) { 
		power_a *= (long(pow(2,16))%(M+1));
		power_a = power_a%(M+1);
		a -= 16;
	}
	power_a *= long(pow(2,a))%(M+1);

	while (b>16) { 
		power_b *= (long(pow(2,16))%(M+1));
		power_b = power_b%(M+1);
		b -= 16;
	}
	power_b *= long(pow(2,b))%(M+1);

	sum = power_a + power_b;
	sum = sum%(M+1);
	if (sum == 1 || sum == 0)
		return 1;
	else return 0;
}

bool onb_II(double a, double b, int M)
{
	long sum, diff;
	long power_a = 1;
	long power_b = 1;
	
	while (a>16) { 
		power_a *= (long(pow(2,16))%(2*M+1));
		power_a = power_a%(2*M+1);
		a -= 16;
	}
	power_a *= long(pow(2,a))%(2*M+1);

	while (b>16) { 
		power_b *= (long(pow(2,16))%(2*M+1));
		power_b = power_b%(2*M+1);
		b -= 16;
	}
	power_b *= long(pow(2,b))%(2*M+1);

	sum = power_a + power_b;
	diff = power_a - power_b;
	while(diff < 0)
		diff += 2*M+1;
	sum = sum%(2*M+1);
	diff = diff%(2*M+1);
	if (sum == 1 || sum == (2*M) || diff == 1 || diff == (2*M))
		return 1;
	else return 0;
}

bool onb(double a, double b, int M, int t)
{
	if(t == 1) return onb_I(a,b,M);
	else return onb_II(a,b,M);
}

int main(int argc, char *argv[])
{
	if(argc != 3)
	{
		cout<<"Usage: ONBindex <size> <type(1or2)>"<<endl;
		exit(1);
	}
	string sz = argv[1];
	string tp = argv[2];
	
	int M = stoi(sz);
	int t = stoi(tp);
	
	vector<vector<bool> > l(M, vector<bool>(M,0));
	vector<vector<int> > idx(M, vector<int>(2,-1));
	int cnt=0;
	int g_cnt = 0;
	int x;
	double i = 0.0, j = 0.0;
	for(i=0.0; i < M; i=i+1.0){
		cnt = 0;
		for(j = 0.0; j<M; j=j+1.0){
			if(onb(i,j,M,t) == 1){
				l[int(i)][int(j)] = 1;
				idx[int(i)][cnt] = int(j);
				cnt++;
				g_cnt++;
			}
		}
	}
	cout<<"Complexity: "<<g_cnt<<endl;
	ofstream fout("index.tmp");
	fout<<idx[0][0];  // We are sure row 1 of M0 contains only 1 nonzero entry
	for(x=1;x<M;x++)
		fout<<" "<<idx[x][0]<<" "<<idx[x][1];
	fout.close();
	
	return 0;
}

